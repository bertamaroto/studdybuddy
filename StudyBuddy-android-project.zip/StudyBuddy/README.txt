Study Buddy - Android app (WebView)
===================================

The app shows your Study Buddy page inside the app using a WebView.
Your login and the page's data are kept by the app after you sign in once.

Signing in
- Google sign-in is blocked by Google inside any app WebView. Use
  "Continue with email" on the Claude login screen instead.
- If the emailed sign-in link opens somewhere else, choose Study Buddy in the
  "Open with" list (or open it from your email app's browser option).

Build with Android Studio: open this folder, let Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

To change the page, edit START_URL in
app/src/main/java/com/studybuddy/app/MainActivity.java
