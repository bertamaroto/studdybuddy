Study Buddy - Android app (Chrome Custom Tab)
=============================================

The app opens your Study Buddy page in a Chrome Custom Tab. Because it is the real
Chrome browser, Google sign-in and 2FA work, and your Claude login and saved chats
persist. Press back to leave the page; tap "Open Study Buddy" to return to it.

Build with Android Studio: open this folder, let Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

To change the page, edit START_URL in
app/src/main/java/com/studybuddy/app/MainActivity.java
