package com.studybuddy.app;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Shows the Study Buddy page INSIDE the app using a WebView.
 * Cookies and local storage are kept by the WebView, so after you log in once
 * you stay logged in.
 */
public class MainActivity extends AppCompatActivity {

    // CHANGE THIS if your Study Buddy link is different.
    private static final String START_URL = "https://claude.ai/artifact/QHgZ1v4KSZHkjkkEhpMdvq";

    // Pages on these domains stay inside the app; everything else opens in the browser.
    private static final String[] ALLOWED_HOSTS = {
            "claude.ai", "anthropic.com", "claudeusercontent.com", "gstatic.com"
    };

    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // lets the page keep data on the device
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true); // the artifact runs in an embedded frame

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();

                // Google blocks its sign-in page inside apps (embedded WebViews).
                if (host != null && host.equals("accounts.google.com")) {
                    Toast.makeText(MainActivity.this,
                            "Google sign-in doesn't work inside apps. Go back and choose \"Continue with email\" instead.",
                            Toast.LENGTH_LONG).show();
                    return true;
                }

                if (("https".equals(scheme) || "http".equals(scheme)) && host != null) {
                    for (String allowed : ALLOWED_HOSTS) {
                        if (host.equals(allowed) || host.endsWith("." + allowed)) return false;
                    }
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        if (savedInstanceState == null) {
            Uri data = getIntent() != null ? getIntent().getData() : null;
            web.loadUrl(data != null ? data.toString() : START_URL);
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    // Lets the emailed Claude sign-in link open inside this app.
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent.getData();
        if (data != null) web.loadUrl(data.toString());
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush(); // keep the login between launches
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
