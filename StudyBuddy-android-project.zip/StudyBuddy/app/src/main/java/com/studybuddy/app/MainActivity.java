package com.studybuddy.app;

import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;

/**
 * Opens Study Buddy in a Chrome Custom Tab. Custom Tabs use the real Chrome browser,
 * so Google sign-in and 2FA work (Google blocks them inside embedded WebViews),
 * and the login and saved chats persist like in Chrome.
 */
public class MainActivity extends AppCompatActivity {

    // CHANGE THIS if your Study Buddy link is different.
    private static final String START_URL = "https://claude.ai/artifact/QHgZ1v4KSZHkjkkEhpMdvq";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        float d = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFFFFF0F7);
        int pad = (int) (32 * d);
        root.setPadding(pad, pad, pad, pad);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        int size = (int) (120 * d);
        root.addView(logo, new LinearLayout.LayoutParams(size, size));

        TextView title = new TextView(this);
        title.setText("Study Buddy \uD83C\uDF38");
        title.setTextSize(26);
        title.setTextColor(0xFFFF7EB6);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, (int) (16 * d), 0, (int) (24 * d));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button open = new Button(this);
        open.setText("Open Study Buddy");
        open.setAllCaps(false);
        open.setOnClickListener(v -> openSite());
        root.addView(open, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);

        if (savedInstanceState == null) {
            openSite();
        }
    }

    private void openSite() {
        CustomTabsIntent tab = new CustomTabsIntent.Builder()
                .setShowTitle(true)
                .setUrlBarHidingEnabled(true)
                .setDefaultColorSchemeParams(new CustomTabColorSchemeParams.Builder()
                        .setToolbarColor(0xFFFF7EB6)
                        .build())
                .build();
        tab.launchUrl(this, Uri.parse(START_URL));
    }
}
